﻿using LogisticManagementSystem.DataAccess.Models;
using LogisticManagementSystem.DataAccess.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.DataAccess.Repository
{
    public class AuthenticationRepository : IAuthenticationRepository
    {
        private readonly LogisticManagementContext _db;
        public AuthenticationRepository(LogisticManagementContext db)
        {
            _db = db;
        }
        public int AddUser(User user, UserDetail userDetails)
        {
            try
            {
                _db.Users.Add(user);
                _db.UserDetails.Add(userDetails);
                return _db.SaveChanges();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error occured while adding user. Please Try Again.");
                Console.WriteLine(ex.Message);
                return -1;
            }
        }

        public User? GetUser(string EmailId)
        {
            try
            {
                return _db.Users.FirstOrDefault(user => user.Email == EmailId);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occured while adding user. Please Try Again.");
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}
