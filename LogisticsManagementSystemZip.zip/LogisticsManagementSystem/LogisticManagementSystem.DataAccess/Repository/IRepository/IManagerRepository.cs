﻿using LogisticManagementSystem.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.DataAccess.Repository.IRepository
{
    public interface IManagerRepository
    {
        public Inventory GetProduct(int productId);

        public List<Inventory>? GetProducts();

        public int AddProduct(Inventory product);

        public int UpdateProduct(Inventory product);
    }
}
