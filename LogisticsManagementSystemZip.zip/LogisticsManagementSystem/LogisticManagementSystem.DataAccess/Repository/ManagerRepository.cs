﻿using LogisticManagementSystem.DataAccess.Models;
using LogisticManagementSystem.DataAccess.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.DataAccess.Repository
{
    public class ManagerRepository : IManagerRepository
    {
        private readonly LogisticManagementContext _db;
        public ManagerRepository(LogisticManagementContext db)
        {
            _db = db;
        }

        public int AddProduct(Inventory product)
        {
            try
            {
                _db.Inventories.Add(product);
                return _db.SaveChanges();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public List<Inventory>? GetProducts()
        {
            try
            {
                List<Inventory> products = _db.Inventories.ToList();
                return products;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public Inventory? GetProduct(int id)
        {
            try
            {
                return _db.Inventories.FirstOrDefault(x => x.Id == id);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public int UpdateProduct(Inventory product)
        {
            try
            {
                Inventory? inventory = _db.Inventories.FirstOrDefault(p=>p.Id == product.Id);
                if (inventory != null)
                {
                    inventory.ProductName = product.ProductName;
                    _db.Inventories.Update(inventory);
                    return _db.SaveChanges();
                }
                else
                {
                    return -1;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }
    }
}
