﻿using LogisticManagementSystem.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.Services.BusinessModels
{
    public class UserDetailsServiceModel
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public string? ShippingAddress { get; set; }

        public string? LicenseNumber { get; set; }

        public string? VehicleType { get; set; }

        public string? VehicleNumber { get; set; }

        public int? WarehouseId { get; set; }

        public int? IsApproved { get; set; }

        public virtual UserServiceModel User { get; set; } = null!;
    }
}
