﻿using LogisticManagementSystem.DataAccess.Models;
using LogisticManagementSystem.DataAccess.Repository.IRepository;
using LogisticManagementSystem.Services.BusinessModels;
using LogisticManagementSystem.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.Services.Services
{
    public class ManagerService : IManagerService
    {
        private readonly IManagerRepository _managerRepo;
        public ManagerService(IManagerRepository managerRepository)
        {
            _managerRepo = managerRepository;
        }

        private Inventory ConverInventoryServiceModelToInventory(InventoryServiceModel product)
        {
            Inventory inventory = new Inventory()
            {
                Id = product.Id,
                ProductName = product.ProductName,
                Price = product.Price,
                ProductDescription = product.ProductDescription,
                IsActive = product.IsActive,
                ProductQuantity = product.ProductQuantity,
                WarehouseId = product.WarehouseId
            };
            return inventory;
        }
        private InventoryServiceModel ConverInventoryToInventoryServiceModel(Inventory inventory)
        {
            InventoryServiceModel product = new InventoryServiceModel()
            {
                Id = inventory.Id,
                ProductName = inventory.ProductName,
                Price = inventory.Price,
                ProductDescription = inventory.ProductDescription,
                IsActive = inventory.IsActive,
                ProductQuantity = inventory.ProductQuantity,
                WarehouseId = inventory.WarehouseId
            };
            return product;
        }
        public int AddProduct(InventoryServiceModel product)
        {
            Inventory inventory = ConverInventoryServiceModelToInventory(product);
            try
            {
                return _managerRepo.AddProduct(inventory);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }

        public List<InventoryServiceModel>? GetProducts()
        {
            try
            {
                List<Inventory> inventories = _managerRepo.GetProducts();
                List<InventoryServiceModel> products = new List<InventoryServiceModel>();

                foreach (Inventory inventory in inventories)
                {
                    products.Add(new InventoryServiceModel()
                    {
                        Id = inventory.Id,
                        IsActive = inventory.IsActive,
                        Price = inventory.Price,
                        ProductDescription = inventory.ProductDescription,
                        ProductName = inventory.ProductName,
                        ProductQuantity = inventory.ProductQuantity,
                        WarehouseId = inventory.WarehouseId
                    });
                }
                return products;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public InventoryServiceModel GetProduct(int productId)
        {
            try
            {
                Inventory inventory =  _managerRepo.GetProduct(productId);
                InventoryServiceModel product = ConverInventoryToInventoryServiceModel(inventory);
                return product;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public int UpdateProduct(InventoryServiceModel product)
        {
            try
            {
                Inventory inventory = ConverInventoryServiceModelToInventory(product);
                return _managerRepo.UpdateProduct(inventory);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return -1;
            }
        }
    }
}
