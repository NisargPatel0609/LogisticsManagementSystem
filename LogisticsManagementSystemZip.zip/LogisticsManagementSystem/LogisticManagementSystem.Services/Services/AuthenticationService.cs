﻿using LogisticManagementSystem.DataAccess.Models;
using LogisticManagementSystem.DataAccess.Repository.IRepository;
using LogisticManagementSystem.Services.BusinessModels;
using LogisticManagementSystem.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace LogisticManagementSystem.Services.Services
{
    public class AuthenticationService : IAuthenticationService
    {
        private readonly IAuthenticationRepository _authRepo;
        public AuthenticationService(IAuthenticationRepository authenticationRepository)
        {
            _authRepo = authenticationRepository;
        }

        public bool SignUp(UserServiceModel tempUser, UserDetailsServiceModel tempUserDetails)
        {
            try
            {
                User? userAlreadyExists = _authRepo.GetUser(tempUser.Email);
                if(userAlreadyExists != null)
                {
                    Console.WriteLine("User Already Exists.");
                    return false;
                }
                else
                {
                    User user = new User()
                    {
                        Name = tempUser.Name,
                        Email = tempUser.Email,
                        Password = tempUser.Password,
                        PhoneNumber = tempUser.PhoneNumber,
                        RoleId = tempUser.RoleId
                    };
                    UserDetail userDetails = new UserDetail()
                    {
                        ShippingAddress = tempUserDetails.ShippingAddress,
                        LicenseNumber = tempUserDetails.LicenseNumber,
                        VehicleNumber = tempUserDetails.VehicleNumber,
                        VehicleType = tempUserDetails.VehicleType,
                        WarehouseId = tempUserDetails.WarehouseId,
                        IsApproved = tempUserDetails.IsApproved,
                        User = user
                    };

                    try
                    {
                        int result = _authRepo.AddUser(user, userDetails);
                        return result > 0 ? true : false;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                        return false;
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return false;
            }
        }

        public int SignIn(string Email, string Password)
        {
            try
            {
                User? user = _authRepo.GetUser(Email);
                if (user != null)
                {
                    if(Password == user.Password)
                    {
                        return user.RoleId;                     
                    }
                    else
                    {
                        Console.WriteLine("Invalid Password.");
                        return -1;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Email.");
                    return -1;
                }
            }
            catch
            {
                Console.WriteLine("Error occurred while Sign In.");
                return -1;
            }
        }
    }
}
