﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsManagement.Views
{
    public class DriverView
    {
        public static void Show()
        {
            Console.Clear();
            Console.WriteLine("----- DRIVER MENU -----");
            Console.WriteLine("1. View Assigned Orders");
            Console.WriteLine("2. Update Order Status");
            Console.WriteLine("3. Logout");
            Console.WriteLine("4. Exit");

            Console.Write("Enter your choice: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ViewAssignedOrders();
                        break;
                    case 2:
                        UpdateOrderStatus();
                        break;
                    case 3:
                        new AuthenticationView().Show();
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        Show();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                Show();
            }
        }

        public static void ViewAssignedOrders()
        {
            Console.WriteLine("list of orders");
            Show();
        }
        public static void UpdateOrderStatus()
        {
            ViewAssignedOrders();
            Console.WriteLine("Select Order for Update Status.");
            Console.WriteLine("updated");
            Show();
        }
    }
}
