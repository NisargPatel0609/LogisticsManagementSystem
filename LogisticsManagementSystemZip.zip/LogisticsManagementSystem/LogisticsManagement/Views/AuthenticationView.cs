﻿using LogisticManagementSystem.Services.BusinessModels;
using LogisticManagementSystem.Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsManagement.Views
{
    public class AuthenticationView
    {
        private static string? Name;
        private static string? Email;
        private static string? Password;
        private static string? ConfirmPassword;
        private static string? PhoneNumber;

        private readonly IAuthenticationService _authenticationService;
        private readonly IManagerService _managerService;

        public AuthenticationView() { }
        public AuthenticationView(IAuthenticationService authenticationService, IManagerService managerService)
        {
            _authenticationService = authenticationService;
            _managerService = managerService;
        }
        public void Show()
        {
            Console.WriteLine("Please Select an option... ");
            Console.WriteLine("1. Login");
            Console.WriteLine("2. Register");
            Console.WriteLine("3. Exit");

            Console.Write("Please enter your choice : ");
            string input = Console.ReadLine();
            if(int.TryParse(input, out int choice))
            {
                switch(choice)
                {
                    case 1:
                        Console.WriteLine("----- Sign In -----");
                        SignIn();
                        break;
                    case 2:
                        SignUp();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        Show();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                Show();
            }
        }


        public void SignIn()
        {
            Console.WriteLine();

            Console.Write("Enter Your Email : ");
            string Email = Console.ReadLine();
            if (!Validation.ValidateEmail(Email)) SignIn();

            Console.Write("Enter Password: ");
            string Password = ReadPassword();
            if (!Validation.ValidatePassword(Password)) SignIn();

            int RoleId = _authenticationService.SignIn(Email,Password);
            if (RoleId > 0)
            {
                Console.WriteLine("Successfully Signed In.");
                switch (RoleId)
                {
                    case 1:
                        AdminView.Show();
                        break;
                    case 2:
                        new ManagerView(_managerService).Show();
                        break;
                    case 3:
                        DriverView.Show();
                        break;
                    case 4:
                        CustomerView.Show();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                Console.WriteLine("Sign In Failed. Please Try Again Later.");
                Show();
            }
        }

        public void SignUp()
        {
            Console.WriteLine("Please Select an option... ");
            Console.WriteLine("1. Manager Sign Up");
            Console.WriteLine("2. Customer Sign Up");
            Console.WriteLine("3. Driver Sign Up");
            Console.WriteLine("4. Back to Main Menu");
            Console.WriteLine("5. Exit");

            Console.Write("Please enter your choice : ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int choice))
            {
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("----- Manager Sign Up -----");
                        ManagerSignUp();
                        SignIn();
                        break;
                    case 2:
                        Console.WriteLine("----- Customer Sign Up -----");
                        CustomerSignUp();
                        SignIn();
                        break;
                    case 3:
                        Console.WriteLine("----- Driver Sign Up -----");
                        DriverSignUp();
                        SignIn();
                        break;
                    case 4:
                        SignUp();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Please enter valid option.");
                        Console.ResetColor();
                        Console.WriteLine();
                        SignUp();
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Invalid input. Please enter a valid number.");
                Console.ResetColor();
                Console.WriteLine();
                SignUp();
            }
        }

        public void UserSignUp()
        {
            Console.Write("Enter Name: ");
            Name = Console.ReadLine();
            if (!Validation.ValidateName(Name)) SignUp();

            Console.Write("Enter Your Email : ");
            Email = Console.ReadLine();
            if (!Validation.ValidateEmail(Email)) SignUp();

            Console.Write("Enter Password: ");
            Password = ReadPassword();
            if (!Validation.ValidatePassword(Password)) SignUp();

            Console.Write("Confirm Password: ");
            ConfirmPassword = ReadPassword();
            if (!Validation.ValidateConfirmpassword(Password, ConfirmPassword)) SignUp();

            Console.Write("Enter Phone Number: ");
            PhoneNumber = Console.ReadLine();
            if (!Validation.ValidatePhone(PhoneNumber)) SignUp();
        }

        public void ManagerSignUp() 
        {
            UserSignUp();

            UserServiceModel user = new UserServiceModel()
            {
                Name = Name,
                Email = Email,
                Password = Password,
                PhoneNumber = PhoneNumber,
                RoleId = 2
            };
            UserDetailsServiceModel userDetails = new UserDetailsServiceModel()
            {
                ShippingAddress = null,
                LicenseNumber = null,
                VehicleNumber = null,
                VehicleType = null,
                WarehouseId = 1,
                IsApproved = 0,
                User = user
            };
            try
            {
                bool result = _authenticationService.SignUp(user, userDetails);
                if (result)
                {
                    Console.WriteLine("Successfully Signed Up.");
                }
                else
                {
                    Console.WriteLine("Authentication Failed.");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error Occurred.");
                Console.WriteLine(ex);
            }
        }
        public void CustomerSignUp()
        {
            UserSignUp();

            Console.Write("Enter Shipping Address : ");
            string Address = Console.ReadLine();
            if (!string.IsNullOrEmpty(Address)) CustomerSignUp();
        }
        public void DriverSignUp()
        {
            UserSignUp();

            Console.Write("Enter Vehicle Type : ");
            string VehicleType = Console.ReadLine();
            if (!string.IsNullOrEmpty(VehicleType)) DriverSignUp();

            Console.Write("Enter Vehicle Number : ");
            string VehicleNumber = Console.ReadLine();
            if (!string.IsNullOrEmpty(VehicleNumber)) DriverSignUp();

            Console.Write("Enter Licence Number: ");
            string LicenceNumber = Console.ReadLine();
            if (!string.IsNullOrEmpty(LicenceNumber)) DriverSignUp();
        }

        static string ReadPassword()
        {
            var pass = string.Empty;
            ConsoleKey key;
            do
            {
                var keyInfo = Console.ReadKey(intercept: true);
                key = keyInfo.Key;

                // remove last character from password
                if (key == ConsoleKey.Backspace && pass.Length > 0)
                {
                    Console.Write("\b \b");
                    pass = pass[0..^1];
                }
                // on any key other than control characters add it to the password
                else if (!char.IsControl(keyInfo.KeyChar))
                {
                    Console.Write("*");
                    pass += keyInfo.KeyChar;
                }
            } while (key != ConsoleKey.Enter);
            Console.WriteLine();
            return pass;
        }
    }
}
